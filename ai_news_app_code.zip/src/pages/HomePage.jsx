import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">AI News Weekly</h1>
        <p className="text-xl text-gray-600">
          Your comprehensive source for the latest AI developments from the past week
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <CategoryCard 
          title="Academic Research" 
          description="Recent AI research papers, breakthroughs, and academic developments"
          link="/academic-research"
          color="bg-blue-100"
        />
        <CategoryCard 
          title="Model Updates" 
          description="Latest updates from major AI companies (Google, OpenAI, Anthropic, etc.)"
          link="/model-updates"
          color="bg-green-100"
        />
        <CategoryCard 
          title="Product Launches" 
          description="New AI products and services released in the past week"
          link="/product-launches"
          color="bg-purple-100"
        />
        <CategoryCard 
          title="AI Agents" 
          description="News about autonomous AI agents, frameworks, and platforms"
          link="/ai-agents"
          color="bg-yellow-100"
        />
        <CategoryCard 
          title="Learning Resources" 
          description="New AI courses, tutorials, and educational materials"
          link="/learning-resources"
          color="bg-red-100"
        />
        <CategoryCard 
          title="About" 
          description="Information about this website and its purpose"
          link="/about"
          color="bg-gray-100"
        />
      </div>

      <div className="mt-16 bg-gray-50 p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">This Week's Highlights</h2>
        <div className="space-y-4">
          <Highlight 
            category="Academic Research"
            title="Advancements in multimodal learning and reasoning"
          />
          <Highlight 
            category="Model Updates"
            title="Google released Gemini 2.5 Pro Experimental with 1M token context window"
          />
          <Highlight 
            category="Product Launches"
            title="Amazon released Nova AI Agent for web browser automation"
          />
          <Highlight 
            category="AI Agents"
            title="Emergence AI released a system that automatically creates AI agents in real-time"
          />
          <Highlight 
            category="Learning Resources"
            title="OpenAI quietly launched OpenAI Academy, offering free AI courses and webinars"
          />
        </div>
      </div>
    </div>
  );
};

const CategoryCard = ({ title, description, link, color }) => {
  return (
    <Link to={link} className={`${color} p-6 rounded-lg transition-transform hover:scale-105`}>
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-gray-700">{description}</p>
      <div className="mt-4 text-blue-600 font-semibold">
        Read more →
      </div>
    </Link>
  );
};

const Highlight = ({ category, title }) => {
  return (
    <div className="border-l-4 border-blue-500 pl-4">
      <span className="text-sm font-semibold text-blue-600">{category}</span>
      <h3 className="font-medium">{title}</h3>
    </div>
  );
};

export default HomePage;
