import React from 'react';
import { Link } from 'react-router-dom';

const AIAgentsPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link to="/" className="text-blue-600 hover:underline">← Back to Home</Link>
      </div>
      
      <h1 className="text-4xl font-bold mb-6">Recent AI Agents News</h1>
      <p className="text-xl text-gray-600 mb-8">
        The latest developments in autonomous AI agents, frameworks, and platforms
      </p>

      <div className="space-y-12">
        <AgentItem
          title="Emergence AI's Autonomous Agent Creation System"
          company="Emergence AI"
          releaseDate="April 1, 2025"
          description="Emergence AI has released a new system that automatically creates AI agents rapidly in real-time based on the work at hand. This no-code, natural language, AI-powered multi-agent builder works in real-time to create agents based on text prompts."
          keyFeatures={[
            "Evaluates incoming tasks and checks existing agent registry",
            "Autonomously generates new agents as needed",
            "Can proactively create agent variants to anticipate related tasks",
            "Described as a milestone in recursive intelligence",
            "Allows 'agents to create agents' within human-defined boundaries"
          ]}
          applications={[
            "Automating data-centric enterprise workflows",
            "ETL pipeline creation",
            "Data migration, transformation, and analysis"
          ]}
          link="https://venturebeat.com/ai/emergence-ais-new-system-automatically-creates-ai-agents-rapidly-in-realtime-based-on-the-work-at-hand/"
        />

        <AgentItem
          title="Microsoft's Security Copilot Expansion"
          company="Microsoft"
          releaseDate="April 2, 2025"
          description="Microsoft has expanded its Security Copilot platform with 11 new autonomous AI agents, including a phishing triage agent handling 30 billion annual phishing alerts and a vulnerability remediation agent for automated patching."
          keyFeatures={[
            "Processes 84 trillion daily security signals",
            "Maintains human oversight frameworks",
            "Automated incident response capabilities",
            "Real-time threat detection and analysis",
            "Integration with existing security infrastructure"
          ]}
          applications={[
            "Enterprise cybersecurity operations",
            "Phishing detection and response",
            "Vulnerability management and patching",
            "Security incident investigation"
          ]}
          link="https://www.microsoft.com/security/blog/2025/04/02/microsoft-security-copilot-autonomous-agents/"
        />

        <AgentItem
          title="AI Agents in Frontend Development"
          company="Various"
          releaseDate="March 31, 2025"
          description="AI agents are quietly transforming frontend development by working in the background to adjust code, optimize layouts, and handle repetitive tasks. This represents an evolution from assistant to autonomous systems in development environments."
          keyFeatures={[
            "Goal-oriented systems that are proactive",
            "Interpret high-level goals without waiting for instructions",
            "Persistent systems embedded in development environments",
            "Continuously learning from codebases and user behavior",
            "Manage complexity and serve as design-to-code translators"
          ]}
          applications={[
            "Code generation and optimization",
            "Layout management and responsive design",
            "Accessibility compliance",
            "Performance optimization",
            "Design implementation"
          ]}
          link="https://thenewstack.io/how-ai-agents-are-quietly-transforming-frontend-development/"
        />

        <AgentItem
          title="Amazon Nova Act"
          company="Amazon"
          releaseDate="April 1, 2025"
          description="Amazon has launched Nova Act, a general-purpose AI agent designed to automate web-based tasks. It handles form filling and calendar management via SDK and is positioned as a competitor to OpenAI's Operator and Anthropic's Claude."
          keyFeatures={[
            "Web automation capabilities",
            "Form filling and data entry",
            "Calendar and scheduling management",
            "SDK for developer integration",
            "Cross-platform compatibility"
          ]}
          applications={[
            "Business process automation",
            "Personal productivity enhancement",
            "Customer service operations",
            "E-commerce workflow optimization"
          ]}
          link="https://www.amazon.com/nova-act"
        />

        <AgentItem
          title="Apple's Project Mulberry"
          company="Apple"
          releaseDate="April 2, 2025"
          description="Apple has accelerated development of Project Mulberry, an AI health coaching agent that analyzes wearable data and provides nutrition/exercise recommendations. iOS 19.4 integration is planned for mid-2025."
          keyFeatures={[
            "Analysis of Apple Watch and Health app data",
            "Personalized nutrition recommendations",
            "Custom exercise planning",
            "Health goal tracking and optimization",
            "Privacy-focused health insights"
          ]}
          applications={[
            "Personal health coaching",
            "Fitness optimization",
            "Nutrition planning",
            "Health monitoring",
            "Wellness improvement"
          ]}
          link="https://www.apple.com/health"
        />
      </div>

      <div className="mt-12 bg-gray-50 p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Key Trends in AI Agents</h2>
        <ul className="space-y-3">
          <li className="flex items-start">
            <span className="bg-blue-100 text-blue-800 font-medium px-2 py-1 rounded mr-2 mt-1">1</span>
            <p><strong>Autonomous Agent Creation:</strong> Systems that can automatically create and deploy AI agents based on specific tasks or goals.</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 text-blue-800 font-medium px-2 py-1 rounded mr-2 mt-1">2</span>
            <p><strong>Multi-Agent Systems:</strong> Frameworks for coordinating multiple specialized AI agents to work together on complex tasks.</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 text-blue-800 font-medium px-2 py-1 rounded mr-2 mt-1">3</span>
            <p><strong>Industry-Specific Agents:</strong> Specialized AI agents for healthcare, finance, cybersecurity, and other domains.</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 text-blue-800 font-medium px-2 py-1 rounded mr-2 mt-1">4</span>
            <p><strong>Human-AI Collaboration:</strong> Focus on creating agent-centric workplaces where humans and AI agents work together.</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 text-blue-800 font-medium px-2 py-1 rounded mr-2 mt-1">5</span>
            <p><strong>Security and Privacy:</strong> Growing emphasis on securing AI agents and enabling them to work with encrypted data.</p>
          </li>
        </ul>
      </div>
    </div>
  );
};

const AgentItem = ({ title, company, releaseDate, description, keyFeatures, applications, link }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-gray-600 mb-4">By {company} • Released {releaseDate}</p>
      
      <p className="text-gray-800 mb-4">{description}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <h3 className="font-semibold mb-2">Key Features:</h3>
          <ul className="list-disc pl-5 space-y-1">
            {keyFeatures.map((feature, index) => (
              <li key={index} className="text-gray-700">{feature}</li>
            ))}
          </ul>
        </div>
        
        <div>
          <h3 className="font-semibold mb-2">Applications:</h3>
          <ul className="list-disc pl-5 space-y-1">
            {applications.map((application, index) => (
              <li key={index} className="text-gray-700">{application}</li>
            ))}
          </ul>
        </div>
      </div>
      
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-blue-600 hover:underline"
      >
        Learn more →
      </a>
    </div>
  );
};

export default AIAgentsPage;
