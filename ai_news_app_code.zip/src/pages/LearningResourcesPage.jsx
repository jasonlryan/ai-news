import React from 'react';
import { Link } from 'react-router-dom';

const LearningResourcesPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link to="/" className="text-blue-600 hover:underline">← Back to Home</Link>
      </div>
      
      <h1 className="text-4xl font-bold mb-6">Recent AI Learning Resources</h1>
      <p className="text-xl text-gray-600 mb-8">
        The latest educational materials, courses, and tutorials for learning AI
      </p>

      <div className="space-y-12">
        <ResourceItem
          title="OpenAI Academy"
          provider="OpenAI"
          releaseDate="March 2025"
          description="OpenAI has quietly launched OpenAI Academy, a free educational platform aimed at democratizing AI education and resources. Previously a paid educational hub, it's now free for all users and offers a wide range of courses and webinars."
          contentTypes={[
            "Video courses",
            "Webinars and live sessions",
            "Hands-on workshops",
            "Expert-led discussions"
          ]}
          popularCourses={[
            "ChatGPT and Beyond: How to Handle AI in Schools",
            "Assistants & Agents Build Hour",
            "Advanced Prompt Engineering",
            "Getting Started with Sora",
            "ChatGPT for Writing & Coding"
          ]}
          link="https://academy.openai.com/"
          bgColor="bg-green-50"
        />

        <ResourceItem
          title="Top YouTube Channels for Learning AI in 2025"
          provider="Various Creators"
          releaseDate="April 2025"
          description="A comprehensive list of 25 game-changing YouTube channels for learning AI in 2025, featuring content from industry experts, researchers, and educators who are making AI education accessible to everyone."
          contentTypes={[
            "Tutorial videos",
            "Expert interviews",
            "Code walkthroughs",
            "Research paper explanations",
            "AI news and updates"
          ]}
          popularCourses={[
            "Andrej Karpathy's channel for practical neural net knowledge",
            "Lex Fridman's long-form interviews with tech leaders",
            "DeepLearning.AI for insider access to AI trends",
            "AI Explained for breakdowns of cutting-edge research",
            "Two Minute Papers for bite-sized research overviews"
          ]}
          link="https://medium.com/@xceed/learning-ai-in-2025-start-with-these-25-game-changing-youtube-channels-e5a32c36facf"
          bgColor="bg-red-50"
        />

        <ResourceItem
          title="SchoolAI"
          provider="SchoolAI"
          releaseDate="April 2025"
          description="SchoolAI is an AI-powered learning platform designed for personalized education in classroom settings. The platform adapts to individual student needs and learning styles to provide a tailored educational experience."
          contentTypes={[
            "Personalized learning paths",
            "Interactive exercises",
            "Progress tracking",
            "Teacher dashboards",
            "AI-generated content"
          ]}
          popularCourses={[
            "Adaptive mathematics curriculum",
            "Personalized reading comprehension",
            "Science exploration with AI assistance",
            "Language learning with AI conversation partners",
            "Creative writing with AI feedback"
          ]}
          link="https://schoolai.com/"
          bgColor="bg-blue-50"
        />

        <ResourceItem
          title="Magic School AI Professional Development"
          provider="Magic School AI"
          releaseDate="April 2025"
          description="Magic School AI offers professional development programs led by educators to improve AI literacy, maximize time savings, and optimize output for teachers and educational professionals."
          contentTypes={[
            "Teacher-focused workshops",
            "Hands-on AI training",
            "Classroom integration guides",
            "Time-saving AI techniques",
            "Educational AI tools"
          ]}
          popularCourses={[
            "AI Literacy for Educators",
            "Time-Saving AI Techniques for Teachers",
            "Integrating AI in Classroom Activities",
            "AI-Enhanced Lesson Planning",
            "Ethical AI Use in Education"
          ]}
          link="https://www.magicschool.ai/professional-development"
          bgColor="bg-purple-50"
        />

        <ResourceItem
          title="AI Governance and Security Learning Resources"
          provider="Guidepoint Security"
          releaseDate="April 2025"
          description="Guidepoint Security has released a collection of learning resources focused on continuous learning in AI governance and security, featuring practical tools, curated courses, and insights to advance expertise in this critical field."
          contentTypes={[
            "Security frameworks",
            "Governance guidelines",
            "Case studies",
            "Best practices",
            "Implementation guides"
          ]}
          popularCourses={[
            "AI Security Fundamentals",
            "Governance Frameworks for AI Systems",
            "Risk Assessment for AI Deployments",
            "Ethical Considerations in AI Security",
            "Regulatory Compliance for AI Applications"
          ]}
          link="https://www.guidepointsecurity.com/blog/supporting-continuous-learning-in-ai-governance-and-security/"
          bgColor="bg-yellow-50"
        />
      </div>

      <div className="mt-12 bg-gray-50 p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Key Trends in AI Learning Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded shadow-sm">
            <h3 className="font-semibold text-lg mb-2">Democratization of AI Education</h3>
            <p>Major AI companies like OpenAI are making high-quality educational resources freely available to the public.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h3 className="font-semibold text-lg mb-2">Focus on Practical Applications</h3>
            <p>Learning resources are increasingly focused on practical, hands-on applications rather than just theoretical knowledge.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h3 className="font-semibold text-lg mb-2">Specialized Content for Different Audiences</h3>
            <p>Resources are being tailored for specific audiences such as educators, developers, business professionals, and even older adults.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h3 className="font-semibold text-lg mb-2">Video-Based Learning</h3>
            <p>YouTube channels and video courses are becoming a primary medium for AI education, offering accessible entry points for beginners.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h3 className="font-semibold text-lg mb-2">Tool-Specific Training</h3>
            <p>Many new resources focus on specific AI tools and platforms (like ChatGPT, Sora, etc.) rather than general AI concepts.</p>
          </div>
          <div className="bg-white p-4 rounded shadow-sm">
            <h3 className="font-semibold text-lg mb-2">Ethical and Responsible AI Use</h3>
            <p>More resources are including content on the ethical implications and responsible use of AI technologies.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const ResourceItem = ({ title, provider, releaseDate, description, contentTypes, popularCourses, link, bgColor }) => {
  return (
    <div className={`${bgColor} p-6 rounded-lg shadow-md`}>
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-gray-600 mb-4">By {provider} • Released {releaseDate}</p>
      
      <p className="text-gray-800 mb-4">{description}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <h3 className="font-semibold mb-2">Content Types:</h3>
          <ul className="list-disc pl-5 space-y-1">
            {contentTypes.map((type, index) => (
              <li key={index} className="text-gray-700">{type}</li>
            ))}
          </ul>
        </div>
        
        <div>
          <h3 className="font-semibold mb-2">Popular Courses/Resources:</h3>
          <ul className="list-disc pl-5 space-y-1">
            {popularCourses.map((course, index) => (
              <li key={index} className="text-gray-700">{course}</li>
            ))}
          </ul>
        </div>
      </div>
      
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-blue-600 hover:underline"
      >
        Explore resources →
      </a>
    </div>
  );
};

export default LearningResourcesPage;
