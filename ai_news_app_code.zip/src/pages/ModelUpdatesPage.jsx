import React from 'react';
import { Link } from 'react-router-dom';

const ModelUpdatesPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link to="/" className="text-blue-600 hover:underline">← Back to Home</Link>
      </div>
      
      <h1 className="text-4xl font-bold mb-6">Recent AI Model Updates</h1>
      <p className="text-xl text-gray-600 mb-8">
        The latest updates from major AI companies including Google, OpenAI, Anthropic, and more
      </p>

      <div className="space-y-12">
        <ModelUpdateItem
          company="Google"
          modelName="Gemini 2.5 Pro Experimental"
          releaseDate="March 29, 2025"
          description="Google has released Gemini 2.5 Pro Experimental, featuring an unprecedented 1 million token context window, allowing the model to process and reason over extremely large amounts of information in a single prompt."
          keyFeatures={[
            "1 million token context window",
            "Enhanced reasoning capabilities across long contexts",
            "Improved performance on complex tasks requiring integration of information across documents",
            "Better handling of code repositories and technical documentation"
          ]}
          link="https://blog.google/technology/ai/gemini-2-5-pro-experimental/"
          logoColor="bg-blue-100"
        />

        <ModelUpdateItem
          company="OpenAI"
          modelName="GPT-4o Image Generator & GPT-4.5 'Orion'"
          releaseDate="March 30, 2025"
          description="OpenAI has launched two significant updates: GPT-4o Image Generator, which brings image generation capabilities directly to ChatGPT, and GPT-4.5 'Orion', their most advanced model yet with improved reasoning and specialized knowledge."
          keyFeatures={[
            "Integrated image generation in ChatGPT",
            "Higher quality and more accurate image outputs",
            "GPT-4.5 'Orion' with enhanced reasoning capabilities",
            "Specialized knowledge in scientific domains",
            "Reduced hallucination rates compared to previous models"
          ]}
          link="https://openai.com/blog/gpt-4o-image-generator"
          logoColor="bg-green-100"
        />

        <ModelUpdateItem
          company="Anthropic"
          modelName="Claude Sonnet 3.7"
          releaseDate="March 28, 2025"
          description="Anthropic has released Claude Sonnet 3.7, a hybrid reasoning model that combines the efficiency of smaller models with the reasoning capabilities of larger ones, offering improved performance at a lower cost."
          keyFeatures={[
            "Hybrid architecture combining different model scales",
            "Enhanced reasoning for complex tasks",
            "50% reduction in cost compared to Claude 3 Opus",
            "Improved handling of nuanced instructions",
            "Better performance on mathematical and scientific reasoning"
          ]}
          link="https://www.anthropic.com/news/claude-sonnet-3-7"
          logoColor="bg-purple-100"
        />

        <ModelUpdateItem
          company="xAI"
          modelName="Grok 3"
          releaseDate="April 1, 2025"
          description="xAI has launched Grok 3, claiming superior performance in mathematics and scientific reasoning compared to other leading models, with a focus on real-time information processing and analysis."
          keyFeatures={[
            "State-of-the-art performance on mathematical benchmarks",
            "Enhanced scientific reasoning capabilities",
            "Real-time information processing from multiple sources",
            "Improved factual accuracy and reduced hallucinations",
            "New API with expanded capabilities for developers"
          ]}
          link="https://x.ai/blog/grok-3"
          logoColor="bg-red-100"
        />

        <ModelUpdateItem
          company="Meta"
          modelName="Llama 3.3"
          releaseDate="March 31, 2025"
          description="Meta has released Llama 3.3, an open-source large language model with improved multilingual capabilities and enhanced performance across a wide range of tasks, available in multiple sizes for different deployment scenarios."
          keyFeatures={[
            "Support for 30+ languages with near-native performance",
            "Available in 8B, 70B, and 400B parameter versions",
            "Optimized for deployment on consumer hardware",
            "Enhanced instruction-following capabilities",
            "Improved coding abilities across multiple programming languages"
          ]}
          link="https://ai.meta.com/blog/llama-3-3/"
          logoColor="bg-yellow-100"
        />
      </div>
    </div>
  );
};

const ModelUpdateItem = ({ company, modelName, releaseDate, description, keyFeatures, link, logoColor }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center mb-4">
        <div className={`${logoColor} w-12 h-12 rounded-full flex items-center justify-center mr-4`}>
          <span className="font-bold text-lg">{company.charAt(0)}</span>
        </div>
        <div>
          <h2 className="text-2xl font-bold">{modelName}</h2>
          <p className="text-gray-600">By {company} • Released {releaseDate}</p>
        </div>
      </div>
      
      <p className="text-gray-800 mb-4">{description}</p>
      
      <div className="mb-4">
        <h3 className="font-semibold mb-2">Key Features:</h3>
        <ul className="list-disc pl-5 space-y-1">
          {keyFeatures.map((feature, index) => (
            <li key={index} className="text-gray-700">{feature}</li>
          ))}
        </ul>
      </div>
      
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-blue-600 hover:underline"
      >
        Read the announcement →
      </a>
    </div>
  );
};

export default ModelUpdatesPage;
