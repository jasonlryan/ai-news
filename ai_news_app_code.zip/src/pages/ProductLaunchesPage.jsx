import React from 'react';
import { Link } from 'react-router-dom';

const ProductLaunchesPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link to="/" className="text-blue-600 hover:underline">← Back to Home</Link>
      </div>
      
      <h1 className="text-4xl font-bold mb-6">Recent AI Product Launches</h1>
      <p className="text-xl text-gray-600 mb-8">
        The latest AI products and services released in the past week
      </p>

      <div className="space-y-12">
        <ProductItem
          name="Amazon Nova AI Agent"
          company="Amazon"
          launchDate="March 31, 2025"
          description="Amazon has released Nova AI Agent, a general-purpose AI agent designed to automate web-based tasks. The agent can handle form filling, calendar management, and other routine tasks via its SDK."
          keyFeatures={[
            "Web browser automation capabilities",
            "Form filling and data entry automation",
            "Calendar and scheduling management",
            "SDK for developer integration",
            "Positioned as competitor to OpenAI's Operator and Anthropic's Claude"
          ]}
          link="https://www.cnbc.com/2025/03/31/amazons-nova-ai-agent-takes-on-rivals-openai-anthropic.html"
          category="AI Agents"
        />

        <ProductItem
          name="Titanium X with CE 25.2"
          company="OpenText"
          launchDate="March 30, 2025"
          description="OpenText has launched Titanium X with CE 25.2, an AI-powered digital workforce platform designed to automate business processes and enhance productivity across organizations."
          keyFeatures={[
            "AI-powered digital workforce capabilities",
            "Business process automation",
            "Enhanced productivity tools",
            "Integration with existing enterprise systems",
            "Advanced analytics and reporting"
          ]}
          link="https://www.bigdatawire.com/this-just-in/opentext-launches-titanium-x-with-ce-25-2-for-ai-powered-digital-workforce/"
          category="Enterprise Solutions"
        />

        <ProductItem
          name="Interests and Health AI"
          company="Amazon"
          launchDate="March 29, 2025"
          description="Amazon has introduced Interests and Health AI features to enhance product discovery on its platform. These new AI-powered features help customers find products that better match their interests and health needs."
          keyFeatures={[
            "Personalized product recommendations based on interests",
            "Health-focused product discovery",
            "AI-powered matching algorithms",
            "Enhanced shopping experience",
            "Privacy-preserving preference learning"
          ]}
          link="https://www.shopifreaks.com/amazon-launches-interests-and-health-ai-to-enhance-product-discovery/"
          category="E-commerce"
        />

        <ProductItem
          name="Ecommerce AI Studio"
          company="Nextech"
          launchDate="March 28, 2025"
          description="Nextech has launched Ecommerce AI Studio, a platform for creating lifelike human product photos using AI. The tool allows e-commerce businesses to showcase products in lifestyle settings with realistic human models without expensive photoshoots."
          keyFeatures={[
            "AI-generated human models for product photography",
            "Lifestyle setting generation",
            "Customizable model appearances and poses",
            "Integration with e-commerce platforms",
            "Cost-effective alternative to traditional photoshoots"
          ]}
          link="https://www.wric.com/business/press-releases/accesswire/1008253/nextechs-advances-its-ai-first-initiative-with-launch-of-ecommerce-ai-studio-showcasing-humans-in-lifestyle-ai-product-photography"
          category="Creative Tools"
        />

        <ProductItem
          name="GT Sophy 2.1"
          company="Sony AI"
          launchDate="April 1, 2025"
          description="Sony AI has released GT Sophy 2.1, an AI racing agent integrated into Gran Turismo 7. This updated version mimics human-like driving behaviors across various skill levels, providing a more realistic and engaging racing experience."
          keyFeatures={[
            "Human-like racing behavior",
            "Adaptive difficulty across skill levels",
            "Integration with Gran Turismo 7",
            "Enhanced racing strategies",
            "Realistic decision-making in race conditions"
          ]}
          link="https://www.sony.com/en/SonyInfo/sony-ai/gt-sophy/"
          category="Gaming"
        />
      </div>
    </div>
  );
};

const ProductItem = ({ name, company, launchDate, description, keyFeatures, link, category }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h2 className="text-2xl font-bold">{name}</h2>
          <p className="text-gray-600">By {company} • Launched {launchDate}</p>
        </div>
        <span className="bg-purple-100 text-purple-800 text-sm font-medium px-3 py-1 rounded-full">
          {category}
        </span>
      </div>
      
      <p className="text-gray-800 mb-4">{description}</p>
      
      <div className="mb-4">
        <h3 className="font-semibold mb-2">Key Features:</h3>
        <ul className="list-disc pl-5 space-y-1">
          {keyFeatures.map((feature, index) => (
            <li key={index} className="text-gray-700">{feature}</li>
          ))}
        </ul>
      </div>
      
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-blue-600 hover:underline"
      >
        Learn more →
      </a>
    </div>
  );
};

export default ProductLaunchesPage;
