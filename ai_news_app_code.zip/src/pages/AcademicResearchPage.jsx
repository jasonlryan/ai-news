import React from 'react';
import { Link } from 'react-router-dom';

const AcademicResearchPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link to="/" className="text-blue-600 hover:underline">← Back to Home</Link>
      </div>
      
      <h1 className="text-4xl font-bold mb-6">Recent AI Academic Research</h1>
      <p className="text-xl text-gray-600 mb-8">
        The latest breakthroughs and papers in AI research from the past week
      </p>

      <div className="space-y-12">
        <ResearchItem
          title="Multimodal Learning and Reasoning Advancements"
          authors="Various research teams"
          description="Several significant papers published on multimodal learning and reasoning, showing how AI systems can better integrate and process information across different modalities (text, images, audio, etc.)."
          highlights={[
            "New architectures for cross-modal attention mechanisms",
            "Improved performance on multimodal benchmarks",
            "Novel approaches to multimodal knowledge representation"
          ]}
          link="https://example.com/paper1"
        />

        <ResearchItem
          title="AI for Scientific Discovery"
          authors="Research teams from leading institutions"
          description="Advancements in AI for scientific discovery and hypothesis generation, demonstrating how AI can accelerate scientific research and discovery processes."
          highlights={[
            "AI-driven hypothesis generation in materials science",
            "Machine learning for drug discovery optimization",
            "Automated experimental design frameworks"
          ]}
          link="https://example.com/paper2"
        />

        <ResearchItem
          title="New Benchmarks for AI Reasoning"
          authors="Collaborative research initiative"
          description="Introduction of new benchmarks for evaluating AI models' reasoning capabilities, providing more rigorous testing of logical reasoning, causal inference, and problem-solving abilities."
          highlights={[
            "Complex multi-step reasoning tasks",
            "Evaluation of causal understanding",
            "Real-world problem-solving scenarios"
          ]}
          link="https://example.com/paper3"
        />

        <ResearchItem
          title="Advances in Neuromorphic Computing"
          authors="University research labs"
          description="Research on neuromorphic computing architectures that more closely mimic the human brain, potentially offering more efficient and powerful AI systems."
          highlights={[
            "Energy-efficient neural network implementations",
            "Spike-based computing models",
            "Hardware-software co-design approaches"
          ]}
          link="https://example.com/paper4"
        />

        <ResearchItem
          title="Ethical Considerations in AI Development"
          authors="Ethics research groups"
          description="Papers addressing ethical considerations in AI development, including fairness, transparency, accountability, and potential societal impacts."
          highlights={[
            "Frameworks for ethical AI development",
            "Methods for detecting and mitigating bias",
            "Approaches to explainable AI"
          ]}
          link="https://example.com/paper5"
        />
      </div>
    </div>
  );
};

const ResearchItem = ({ title, authors, description, highlights, link }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-gray-600 italic mb-4">By {authors}</p>
      <p className="text-gray-800 mb-4">{description}</p>
      
      <div className="mb-4">
        <h3 className="font-semibold mb-2">Key Highlights:</h3>
        <ul className="list-disc pl-5 space-y-1">
          {highlights.map((highlight, index) => (
            <li key={index} className="text-gray-700">{highlight}</li>
          ))}
        </ul>
      </div>
      
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-blue-600 hover:underline"
      >
        Read the full paper →
      </a>
    </div>
  );
};

export default AcademicResearchPage;
