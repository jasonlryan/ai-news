import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AcademicResearchPage from './pages/AcademicResearchPage';
import ModelUpdatesPage from './pages/ModelUpdatesPage';
import ProductLaunchesPage from './pages/ProductLaunchesPage';
import AIAgentsPage from './pages/AIAgentsPage';
import LearningResourcesPage from './pages/LearningResourcesPage';
import AboutPage from './pages/AboutPage';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/academic-research" element={<AcademicResearchPage />} />
            <Route path="/model-updates" element={<ModelUpdatesPage />} />
            <Route path="/product-launches" element={<ProductLaunchesPage />} />
            <Route path="/ai-agents" element={<AIAgentsPage />} />
            <Route path="/learning-resources" element={<LearningResourcesPage />} />
            <Route path="/about" element={<AboutPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
