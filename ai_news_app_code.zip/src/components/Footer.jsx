import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">AI News Weekly</h3>
            <p className="text-gray-300">
              Your comprehensive source for the latest AI developments from the past week.
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link to="/academic-research" className="text-gray-300 hover:text-white">Academic Research</Link></li>
              <li><Link to="/model-updates" className="text-gray-300 hover:text-white">Model Updates</Link></li>
              <li><Link to="/product-launches" className="text-gray-300 hover:text-white">Product Launches</Link></li>
              <li><Link to="/ai-agents" className="text-gray-300 hover:text-white">AI Agents</Link></li>
              <li><Link to="/learning-resources" className="text-gray-300 hover:text-white">Learning Resources</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">About</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-300 hover:text-white">About This Website</Link></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Data Sources</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Technology</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400">
          <p>© {new Date().getFullYear()} AI News Weekly. All rights reserved.</p>
          <p className="mt-2">Created with React, Vite, and Tailwind CSS.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
